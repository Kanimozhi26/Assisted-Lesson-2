package constructors_example;
class constructor{
	constructor(){
		System.out.println("I am a Default Constructor");
	}
}
public class default_constructor {
	public static void main(String[] args) {
		constructor obj=new constructor();

	}

}
